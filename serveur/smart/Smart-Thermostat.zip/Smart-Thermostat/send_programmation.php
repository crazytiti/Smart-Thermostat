<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="fr">
 <head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="generator" content="openElement (1.57.9)" />
  <title>send_config</title>
  <link id="openElement" rel="stylesheet" type="text/css" href="WEFiles/Css/v02/openElement.css?v=50491126800" />
  <link id="siteFonts" rel="stylesheet" type="text/css" href="Files/Fonts/Fonts.css?v=50491126800" />
  <link id="OEBase" rel="stylesheet" type="text/css" href="send_programmation.css?v=50491126800" />
  <!--[if lte IE 7]>
  <link rel="stylesheet" type="text/css" href="WEFiles/Css/ie7.css?v=50491126800" />
  <![endif]-->
  <script type="text/javascript">
   var WEInfoPage = {"PHPVersion":"phpOK","OEVersion":"1-57-9","PagePath":"send_programmation","Culture":"DEFAULT","LanguageCode":"FR","RelativePath":"","RenderMode":"Export","PageAssociatePath":"send_programmation","EditorTexts":null};
  </script>
  <script type="text/javascript" src="WEFiles/Client/jQuery/1.10.2.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/jQuery/migrate.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/Common/oe.min.js?v=50491126800"></script>
 </head>
 <body class="" data-gl="{&quot;KeywordsHomeNotInherits&quot;:false}">
  <form id="XForm" method="post" action="#"></form>
  <div id="XBody" class="BaseDiv RWidth OEPageXbody OESK_XBody_Default" style="z-index:0">
   <div class="OESZ OESZ_DivContent OESZG_XBody">
    <div class="OESZ OESZ_XBodyContent OESZG_XBody OECT OECT_Content OECTAbs">
     <div id="WE6fc5503f3a" class="BaseDiv RNone OEWECodeBlock OESK_WECodeBlock_Default" style="z-index:1">
      <div class="OESZ OESZ_DivContent OESZG_WE6fc5503f3a">
       <?php require_once('/var/www/html/thermostat/thermostat_func.php'); ?>
       <?php
       //LUNDI
       configPlanning ($_GET["N_planning_aff"], "2", $_GET["H2"], $_GET["T1"], $_GET["H16"], $_GET["T15"], $_GET["H30"], $_GET["T29"],
        $_GET["H44"], $_GET["T43"], $_GET["H58"], $_GET["T57"], $_GET["H72"], $_GET["T71"]
        , $_GET["H86"], $_GET["T85"], $_GET["H100"], $_GET["T99"], $_GET["H114"], $_GET["T113"], "23:59", $_GET["T127"]); 
       
       //MARDI
       configPlanning ($_GET["N_planning_aff"], "3", $_GET["H4"], $_GET["T3"], $_GET["H18"], $_GET["T17"], $_GET["H32"], $_GET["T31"],
        $_GET["H46"], $_GET["T45"], $_GET["H60"], $_GET["T59"], $_GET["H74"], $_GET["T73"]
        , $_GET["H88"], $_GET["T87"], $_GET["H102"], $_GET["T101"], $_GET["H116"], $_GET["T115"], "23:59", $_GET["T129"]); 
       
       //MERCREDI
       configPlanning ($_GET["N_planning_aff"], "4", $_GET["H6"], $_GET["T5"], $_GET["H20"], $_GET["T19"], $_GET["H34"], $_GET["T33"],
        $_GET["H48"], $_GET["T47"], $_GET["H62"], $_GET["T61"], $_GET["H76"], $_GET["T75"]
        , $_GET["H90"], $_GET["T89"], $_GET["H104"], $_GET["T103"], $_GET["H118"], $_GET["T117"], "23:59", $_GET["T131"]); 
       
       //JEUDI
       configPlanning ($_GET["N_planning_aff"], "5", $_GET["H8"], $_GET["T7"], $_GET["H22"], $_GET["T21"], $_GET["H36"], $_GET["T35"],
        $_GET["H50"], $_GET["T49"], $_GET["H64"], $_GET["T63"], $_GET["H78"], $_GET["T77"]
        , $_GET["H92"], $_GET["T91"], $_GET["H106"], $_GET["T105"], $_GET["H120"], $_GET["T119"], "23:59", $_GET["T133"]); 
       
       //VENDREDI
       configPlanning ($_GET["N_planning_aff"], "6", $_GET["H10"], $_GET["T9"], $_GET["H24"], $_GET["T23"], $_GET["H38"], $_GET["T37"],
        $_GET["H52"], $_GET["T51"], $_GET["H66"], $_GET["T65"], $_GET["H80"], $_GET["T79"]
        , $_GET["H94"], $_GET["T93"], $_GET["H108"], $_GET["T107"], $_GET["H122"], $_GET["T121"], "23:59", $_GET["T135"]); 
       
       //SAMEDI
       configPlanning ($_GET["N_planning_aff"], "7", $_GET["H12"], $_GET["T11"], $_GET["H26"], $_GET["T25"], $_GET["H40"], $_GET["T39"],
        $_GET["H54"], $_GET["T53"], $_GET["H68"], $_GET["T67"], $_GET["H82"], $_GET["T81"]
        , $_GET["H96"], $_GET["T95"], $_GET["H110"], $_GET["T109"], $_GET["H124"], $_GET["T123"], "23:59", $_GET["T137"]); 
       
       //DIMANCHE
       configPlanning ($_GET["N_planning_aff"], "1", $_GET["H14"], $_GET["T13"], $_GET["H28"], $_GET["T27"], $_GET["H42"], $_GET["T41"],
        $_GET["H56"], $_GET["T55"], $_GET["H70"], $_GET["T69"], $_GET["H84"], $_GET["T83"]
        , $_GET["H98"], $_GET["T97"], $_GET["H112"], $_GET["T111"], $_GET["H126"], $_GET["T125"], "23:59", $_GET["T139"]); 
       
       ?> <br>
       
       Configuration enregistrée.<br>
       Planning n° : 
       <?php echo getconfig('N_planning'); ?> <br>
       
       Retour à la page précédente en cours.
       
       <meta http-equiv="refresh" content="5;url=./Planning.php?N_planning_aff=<?php echo getconfig('N_planning'); ?>" />
      </div>
     </div>
    </div>
    <div class="OESZ OESZ_XBodyFooter OESZG_XBody OECT OECT_Footer OECTAbs"></div>
   </div>
  </div>
 </body>
</html>