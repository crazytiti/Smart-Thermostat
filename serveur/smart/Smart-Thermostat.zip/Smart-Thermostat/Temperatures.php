<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="fr">
 <head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="generator" content="openElement (1.57.9)" />
  <link id="openElement" rel="stylesheet" type="text/css" href="WEFiles/Css/v02/openElement.css?v=50491126800" />
  <link id="siteFonts" rel="stylesheet" type="text/css" href="Files/Fonts/Fonts.css?v=50491126800" />
  <link id="OETemplate1" rel="stylesheet" type="text/css" href="Templates/Base_Menu_Alt.css?v=50491126800" />
  <link id="OEBase" rel="stylesheet" type="text/css" href="Temperatures.css?v=50491126800" />
  <link rel="stylesheet" type="text/css" href="WEFiles/Css/WEMenu-v23.css?v=50491126800" />
  <link rel="stylesheet" type="text/css" href="WEFiles/Css/opentip.css?v=50491126800" />
  <!--[if lte IE 7]>
  <link rel="stylesheet" type="text/css" href="WEFiles/Css/ie7.css?v=50491126800" />
  <![endif]-->
  <script type="text/javascript">
   var WEInfoPage = {"PHPVersion":"phpOK","OEVersion":"1-57-9","PagePath":"Temperatures","Culture":"DEFAULT","LanguageCode":"FR","RelativePath":"","RenderMode":"Export","PageAssociatePath":"Temperatures","EditorTexts":null};
  </script>
  <script type="text/javascript" src="WEFiles/Client/jQuery/1.10.2.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/jQuery/migrate.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/Common/oe.min.js?v=50491126800"></script>
  <script type="text/javascript" src="Temperatures(var).js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/WEMenu-v23.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/EG/EG891d4068/Js/anchor-scroll-v13.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/jQuery/Plugins/jquery.form.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/opentip-jquery.min.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/WESendMail-v210.js?v=50491126800"></script>
  <style id="OEScriptManager" type="text/css">
   .position-fixed,
   .OECTRel>.OERelLine>.BaseDiv.position-fixed 
   { 
   	position: fixed !important;
   }
  </style>
  <?php require_once('/var/www/html/thermostat/thermostat_func.php'); ?>
  <?php // variables
  	date_default_timezone_set('Europe/Paris');		//Timezone
  	if (isset($_POST['date_debut'])){
  		$date_debut = $_POST['date_debut'];}
  	else{
  		$date_debut = date('Y-m-d H:i', time() - 345600);}
  	if (isset($_POST['date_fin'])){
  		$date_fin = $_POST['date_fin'];}
  	else{
  		$date_fin = date('Y-m-d H:i');}
  ?>
  
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  
  <script type="text/javascript">
    google.charts.load('current', {packages: ['corechart', 'controls'], 'language': 'fr'});
    google.charts.setOnLoadCallback(drawDashboard);
  
    function drawDashboard() {
  
      var data = new google.visualization.DataTable();
          data.addColumn('date', 'Date');
          data.addColumn('number', 'Température');
          data.addColumn({type:'string', role:'style'});
          data.addColumn('number', 'Consigne');
          data.addRows([<?php echo getTempGraph ($date_debut, $date_fin); ?>]);
  
      var dashboard = new google.visualization.Dashboard(
              document.getElementById('puissance'));
  
      var rangeSlider = new google.visualization.ControlWrapper({
            'controlType': 'ChartRangeFilter',
            'containerId': 'filter_div',
            'options': {
               filterColumnLabel : 'Date',
               ui : {chartType: 'LineChart', chartOptions: {
                               height : 80,
                               backgroundColor: '#FFF',
                               colors : ['#375D81', '#ABC8E2'],
                               curveType : 'function',
                               focusTarget : 'category',
                               lineWidth : '1',
                               'legend': {'position': 'none'},
                               'hAxis': {'textPosition': 'in'},
                               'vAxis': {
                                 'textPosition': 'none',
                                 'gridlines': {'color': 'none'}
                               }
                   }}
            }
          });
          
      var lineChart = new google.visualization.ChartWrapper({
            'chartType': 'LineChart',
            'containerId': 'chart_div',
            'options': {
                               //title: 'Température actuelle : <?php echo getActualTemp (); ?>°c. Historique :',
                               height : 400,
                               backgroundColor: '#FFF',
                               colors : ['#375D81', '#ABC8E2'],
                               curveType : 'function',
                               focusTarget : 'category',
                               lineWidth : '1',
                               legend : {position: 'bottom',  alignment: 'center', textStyle: {color: '#333', fontSize: 16}},
                               vAxis : {textStyle : {color : '#555', fontSize : '16'}, gridlines : {color: '#CCC', count: 'auto'}, baselineColor : '#AAA', minValue : 0},
                               hAxis : {textStyle : {color : '#555'}, gridlines : {color: '#DDD'}}
            }
          });
  
      dashboard.bind(rangeSlider, lineChart);
      dashboard.draw(data);
  
    }
  
  </script><?php
  	if (isset($oeHeaderInlineCode)) echo $oeHeaderInlineCode;
  ?>
 </head>
 <body class="RWAuto" data-gl="{&quot;KeywordsHomeNotInherits&quot;:false}"><?php
  	if (isset($oeStartBodyInlineCode)) echo $oeStartBodyInlineCode;
  ?>
  <form id="XForm" method="post" action="#"></form>
  <div id="XBody" class="BaseDiv RWidth OEPageXbody OESK_XBody_Default" style="z-index:1000">
   <div class="OESZ OESZ_DivContent OESZG_XBody">
    <div class="OESZ OESZ_XBodyContent OESZG_XBody OECT OECT_Content OECTRel">
     <div class="OERelLine OEHAlignL OEVAlignB">
      <div id="WEcc5198b10f" class="BaseDiv RBoth OEWEPanel OESK_WEPanel_Default  menu position-fixed" style="z-index:8">
       <div class="OESZ OESZ_DivContent OESZG_WEcc5198b10f">
        <div class="OECT OECT_Content OECTRel OEDynTag0" style="overflow:hidden">
         <div class="OERelLine OEHAlignC OEVAlignT">
          <div id="WE2474775d61" class="BaseDiv RBoth OEWEPanel OESK_WEPanel_Default  transitions" style="z-index:1">
           <div class="OESZ OESZ_DivContent OESZG_WE2474775d61">
            <div class="OECT OECT_Content OECTRel OEDynTag0" style="overflow:hidden">
             <div class="OERelLine OEHAlignC OEVAlignM">
              <div id="WE2af7da3a5d" class="BaseDiv RBoth OEWEImage OESK_WEImage_Default  hand transitions" style="z-index:7">
               <div class="OESZ OESZ_DivContent OESZG_WE2af7da3a5d">
                <img src="WEFiles/Image/WEImage/menu-mobile60x60-WEMENU_MOBILE.png" class="OESZ OESZ_Img OESZG_WE2af7da3a5d" alt="" />
               </div>
              </div><div id="WEd0eee7eee2" class="BaseDiv RBoth OEWEImage OESK_WEImage_Default" style="z-index:8">
               <div class="OESZ OESZ_DivContent OESZG_WEd0eee7eee2">
                <a href="index.htm">
                 <img src="Files/Image/logo.png" class="OESZ OESZ_Img OESZG_WEd0eee7eee2" alt="" />
                </a>
               </div>
              </div><div id="WE4539e157fc" class="BaseDiv RNone OEWELink OESK_WELink_Default OE_ActiveLink  transitions btmobile" style="z-index:6" onclick="return OE.Navigate.open(event,'Temperatures.php',1)">
               <div class="OESZ OESZ_DivContent OESZG_WE4539e157fc OE_ActiveLink">
                <a class="OESZ OESZ_Link OESZG_WE4539e157fc OE_ActiveLink ContentBox" data-cd="PageLink" href="Temperatures.php">Températures</a>
               </div>
              </div><div id="WE6c1ed42a4f" class="BaseDiv RNone OEWELink OESK_WELink_Default  transitions btmobile" style="z-index:7" onclick="return OE.Navigate.open(event,'Planning.php',1)">
               <div class="OESZ OESZ_DivContent OESZG_WE6c1ed42a4f">
                <a class="OESZ OESZ_Link OESZG_WE6c1ed42a4f ContentBox" data-cd="PageLink" href="Planning.php">PLANNING</a>
               </div>
              </div><div id="WE8f6dc88e43" class="BaseDiv RNone OEWELink OESK_WELink_Default  transitions btmobile" style="z-index:7" onclick="return OE.Navigate.open(event,'config.php',1)">
               <div class="OESZ OESZ_DivContent OESZG_WE8f6dc88e43">
                <a class="OESZ OESZ_Link OESZG_WE8f6dc88e43 ContentBox" data-cd="PageLink" href="config.php">CONFIG</a>
               </div>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
     <div class="OERelLine OEHAlignC OEVAlignT">
      <div id="WE25c0eeced7" class="BaseDiv RBoth OEWEPanel OESK_WEPanel_Default" style="z-index:1005">
       <div class="OESZ OESZ_DivContent OESZG_WE25c0eeced7">
        <div class="OECT OECT_Content OECTRel OEDynTag0" style="overflow:hidden">
         <div class="OERelLine OEHAlignL OEVAlignB">
          <div id="WE3a06e930c0" class="BaseDiv RNone OEWELabel OESK_WELabel_Default" style="z-index:1001">
           <div class="OESZ OESZ_DivContent OESZG_WE3a06e930c0">
            <span class="OESZ OESZ_Text OESZG_WE3a06e930c0 ContentBox">Température actuelle : &nbsp;</span>
           </div>
          </div><div id="WEe700674cfc" class="BaseDiv RNone OEWECodeBlock OESK_WECodeBlock_Default" style="z-index:1002">
           <div class="OESZ OESZ_DivContent OESZG_WEe700674cfc">
            <?php require_once('/var/www/html/thermostat/thermostat_func.php'); ?>
            <?php echo getActualTemp (); ?>°c
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
     <div class="OERelLine OEHAlignL OEVAlignB">
      <div id="WE5080974787" class="BaseDiv RBoth OEWEPanel OESK_WEPanel_Default  transitions" style="z-index:1001">
       <div class="OESZ OESZ_DivContent OESZG_WE5080974787">
        <div class="OECT OECT_Content OECTRel OEDynTag0" style="overflow:hidden">
         <div class="OERelLine OEHAlignC OEVAlignT">
          <div id="WE82e602c11b" class="BaseDiv RBoth OEWEPanel OESK_WEPanel_Default  apply-smoove" style="z-index:1001">
           <div class="OESZ OESZ_DivContent OESZG_WE82e602c11b">
            <div class="OECT OECT_Content OECTRel OEDynTag0" style="overflow:hidden">
             <div class="OERelLine OEHAlignC OEVAlignT">
              <div id="WE2e2a0e6c2e" class="BaseDiv RBoth OEWEPanel OESK_WEPanel_Default" style="z-index:1004">
               <div class="OESZ OESZ_DivContent OESZG_WE2e2a0e6c2e">
                <div class="OECT OECT_Content OECTRel OEDynTag0" style="overflow:hidden">
                 <div class="OERelLine OEHAlignL OEVAlignB">
                  <div id="WE26d7127433" class="BaseDiv RNone OEWELabel OESK_WELabel_Default" style="z-index:1001">
                   <div class="OESZ OESZ_DivContent OESZG_WE26d7127433">
                    <span class="OESZ OESZ_Text OESZG_WE26d7127433 ContentBox">Histogramme<br /></span>
                   </div>
                  </div>
                 </div>
                 <div class="OERelLine OEHAlignL OEVAlignB">
                  <div id="WE777eba9356" class="BaseDiv RNone OEWECodeBlock OESK_WECodeBlock_Default" style="z-index:1003">
                   <div class="OESZ OESZ_DivContent OESZG_WE777eba9356">
                    <script src="../thermostat/dt_picker/jquery.js"></script>
                    <link rel="stylesheet" type="text/css" href="../thermostat/dt_picker/jquery.datetimepicker.css"/>
                    
                    <FORM METHOD="POST" ACTION="" >
                    	<p><font color="white">
                    		Début de période
                    		<input type="text" value=$date_debut id="datetimepicker1" name="date_debut"/>
                    		Fin de période 
                    		<input type="text" value=$date_fin id="datetimepicker3" name="date_fin"/>
                    		<input type="submit" value="Afficher" id="bt_afficher" /><br><br>
                    	</font> </p> 
                    </FORM>
                    
                    <script src="../thermostat/dt_picker/jquery.datetimepicker.js"></script>
                    <script>
                    $('#datetimepicker1').datetimepicker({value:'<?php echo($date_debut); ?>',step:60});
                    $('#datetimepicker3').datetimepicker({value:'<?php echo($date_fin); ?>',step:60});
                    </script>
                   </div>
                  </div>
                 </div>
                 <div class="OERelLine OEHAlignL OEVAlignB">
                  <div id="WE2d269acbcc" class="BaseDiv RBoth OEWECodeBlock OESK_WECodeBlock_Default" style="z-index:1002">
                   <div class="OESZ OESZ_DivContent OESZG_WE2d269acbcc">
                    <?php require_once('/var/www/html/thermostat/thermostat_func.php'); ?>
                    
                    <div id="puissance">
                      <div id="chart_div"></div>
                      <div id="filter_div"></div>
                    </div>
                   </div>
                  </div>
                 </div>
                </div>
               </div>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
     </div>
    </div>
    <div class="OESZ OESZ_XBodyFooter OESZG_XBody OECT OECT_Footer OECTAbs"></div>
    <div id="WEd280877b93" class="BaseDiv RBoth OEWEMenu OESK_WEMenu_Default" style="z-index:1">
     <div class="OESZ OESZ_DivContent OESZG_WEd280877b93">
      <div class="OESZ OESZ_WEMenuGroup OESZG_WEd280877b93 OEo" style="display:none" id="WEMenu8db7c6">
       <div class="OESZ OESZ_WEMenuTop OESZG_WEd280877b93"></div>
       <div class="OESZ OESZ_WEMenuItem OESZG_WEd280877b93" id="WEMenu33b28d">
        <table onclick="return OE.Navigate.open(event,'index.htm#welcome',1)" style="border-spacing: 0px; border-collapse: collapse;" class="OESZ OESZ_WEMenuItemTable OESZG_WEd280877b93">
         <tr>
          <td class="OESZ OESZ_WEMenuText OESZG_WEd280877b93">
           <a href="index.htm#welcome">ACCUEIL</a>
          </td>
         </tr>
        </table>
       </div>
       <div class="OESZ OESZ_WEMenuItem OESZG_WEd280877b93" id="WEMenuebcb2d">
        <table onclick="return OE.Navigate.open(event,'index.htm#about',1)" style="border-spacing: 0px; border-collapse: collapse;" class="OESZ OESZ_WEMenuItemTable OESZG_WEd280877b93">
         <tr>
          <td class="OESZ OESZ_WEMenuText OESZG_WEd280877b93">
           <a href="index.htm#about">A PROPOS</a>
          </td>
         </tr>
        </table>
       </div>
       <div class="OESZ OESZ_WEMenuItem OESZG_WEd280877b93" id="WEMenu15715b">
        <table onclick="return OE.Navigate.open(event,'index.htm#gallery',1)" style="border-spacing: 0px; border-collapse: collapse;" class="OESZ OESZ_WEMenuItemTable OESZG_WEd280877b93">
         <tr>
          <td class="OESZ OESZ_WEMenuText OESZG_WEd280877b93">
           <a href="index.htm#gallery">GALERIE</a>
          </td>
         </tr>
        </table>
       </div>
       <div class="OESZ OESZ_WEMenuItem OESZG_WEd280877b93" id="WEMenu02a5ed">
        <table onclick="return OE.Navigate.open(event,'index.htm#news',1)" style="border-spacing: 0px; border-collapse: collapse;" class="OESZ OESZ_WEMenuItemTable OESZG_WEd280877b93">
         <tr>
          <td class="OESZ OESZ_WEMenuText OESZG_WEd280877b93">
           <a href="index.htm#news">ACTUALITES</a>
          </td>
         </tr>
        </table>
       </div>
       <div class="OESZ OESZ_WEMenuItem OESZG_WEd280877b93" id="WEMenuea4382">
        <table onclick="return OE.Navigate.open(event,'index.htm#contact',1)" style="border-spacing: 0px; border-collapse: collapse;" class="OESZ OESZ_WEMenuItemTable OESZG_WEd280877b93">
         <tr>
          <td class="OESZ OESZ_WEMenuText OESZG_WEd280877b93">
           <a href="index.htm#contact">CONTACT</a>
          </td>
         </tr>
        </table>
       </div>
       <div class="OESZ OESZ_WEMenuBottom OESZG_WEd280877b93"></div>
      </div>
     </div>
    </div>
    <div id="WEff841c533b" class="BaseDiv RBoth OEEG891d4068 OESK_EG891d4068_Default" style="z-index:2">
     <div class="OESZ OESZ_DivContent OESZG_WEff841c533b"></div>
    </div>
   </div>
  </div>
 </body>
</html>