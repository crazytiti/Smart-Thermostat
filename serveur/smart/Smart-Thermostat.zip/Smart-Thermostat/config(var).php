<?php
$OESiteUploadDirectory = "Upload";
$OEConfWEListBox = '{"WE733e434f79":{"InputName":"mode"}}';
$OEConfWETextBox = '{"WE410fc3b373":{"InputName":"calibration"},"WE8fdab9358a":{"InputName":"hysteresis"},"WE67188b1219":{"InputName":"fuseau"}}';
