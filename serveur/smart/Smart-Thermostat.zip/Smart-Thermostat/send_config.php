<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="fr">
 <head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="generator" content="openElement (1.57.9)" />
  <title>send_config</title>
  <link id="openElement" rel="stylesheet" type="text/css" href="WEFiles/Css/v02/openElement.css?v=50491126800" />
  <link id="siteFonts" rel="stylesheet" type="text/css" href="Files/Fonts/Fonts.css?v=50491126800" />
  <link id="OEBase" rel="stylesheet" type="text/css" href="send_config.css?v=50491126800" />
  <!--[if lte IE 7]>
  <link rel="stylesheet" type="text/css" href="WEFiles/Css/ie7.css?v=50491126800" />
  <![endif]-->
  <script type="text/javascript">
   var WEInfoPage = {"PHPVersion":"phpOK","OEVersion":"1-57-9","PagePath":"send_config","Culture":"DEFAULT","LanguageCode":"FR","RelativePath":"","RenderMode":"Export","PageAssociatePath":"send_config","EditorTexts":null};
  </script>
  <script type="text/javascript" src="WEFiles/Client/jQuery/1.10.2.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/jQuery/migrate.js?v=50491126800"></script>
  <script type="text/javascript" src="WEFiles/Client/Common/oe.min.js?v=50491126800"></script>
 </head>
 <body class="" data-gl="{&quot;KeywordsHomeNotInherits&quot;:false}">
  <form id="XForm" method="post" action="#"></form>
  <div id="XBody" class="BaseDiv RWidth OEPageXbody OESK_XBody_Default" style="z-index:0">
   <div class="OESZ OESZ_DivContent OESZG_XBody">
    <div class="OESZ OESZ_XBodyContent OESZG_XBody OECT OECT_Content OECTAbs">
     <div id="WE54c47316e0" class="BaseDiv RNone OEWECodeBlock OESK_WECodeBlock_Default" style="z-index:1">
      <div class="OESZ OESZ_DivContent OESZG_WE54c47316e0">
       <?php require_once('/var/www/html/thermostat/thermostat_func.php'); ?>
       <br>
       <?php setconfig('mode', $_GET["mode"]); ?> <br>
       <?php setconfig('calibration', $_GET["calibration"]); ?> <br>
       <?php setconfig('hysteresis', $_GET["hysteresis"]); ?> <br>
       
       Configuration enregistrée.<br>
       Mode : 
       <?php echo getconfig('mode'); ?> <br>
       Planning n° : 
       <?php echo getconfig('N_planning'); ?> <br>
       Calibration : 
       <?php echo getconfig('calibration'); ?> <br>
       Hysteresis : 
       <?php echo getconfig('hysteresis'); ?> <br>
       
       Retour à la page précédente en cours.
       
       <meta http-equiv="refresh" content="5;url=./config.php" />
      </div>
     </div>
    </div>
    <div class="OESZ OESZ_XBodyFooter OESZG_XBody OECT OECT_Footer OECTAbs"></div>
   </div>
  </div>
 </body>
</html>